#!/usr/bin/env python
import brain_games.games.progression


def main():
    brain_games.games.progression.progression_game()


if __name__ == '__main__':
    main()
