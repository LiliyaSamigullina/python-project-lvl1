#!/usr/bin/env python
import brain_games.games.even


def main():
    brain_games.games.even.even_game()


if __name__ == '__main__':
    main()
