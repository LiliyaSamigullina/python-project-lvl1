#!/usr/bin/env python
import brain_games.games.gcd


def main():
    brain_games.games.gcd.gcd_game()


if __name__ == '__main__':
    main()
