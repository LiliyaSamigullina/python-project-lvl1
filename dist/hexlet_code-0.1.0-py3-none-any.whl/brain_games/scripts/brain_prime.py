#!/usr/bin/env python
import brain_games.games.prime


def main():
    brain_games.games.prime.prime_game()


if __name__ == '__main__':
    main()
